import React from 'react';

function Team(){
    return(
        <div className='container'>
            <h1>Team Page </h1>
            
        </div>
    )
}
export default Team;