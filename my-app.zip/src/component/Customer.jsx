import React from 'react';
function Customer(){
    return(
        <div className='container'>
                <h1>Customer</h1>
        </div>
    )
}
export default Customer;