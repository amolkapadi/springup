import React from 'react';
function Locations(){
    return (
        <div className='container'>
            <h1>Location</h1>
        </div>
    )   
}
export default Locations;